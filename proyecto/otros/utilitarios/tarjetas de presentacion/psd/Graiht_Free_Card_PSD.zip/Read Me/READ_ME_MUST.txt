THANK YOU FOR PURCHASING THIS FILE!
 
IMPORTANT: Before you keep reading please rate 5 stars the file,  and dont worry, you can change the rating as many times as you wish. Contact me and i will help you.If you feel any Question, contact me. 
 MY CONTACT Facebook Page: www.facebook.com/evnybd 
 
------------------------------------------------------------------------------------------------------------------------------------------ 

Fonts Information: 
Lato Font:- http://www.fontsquirrel.com/fonts/lato
Nexa:- http://fontfabric.com/nexa-free-font/
Titillium Font:- http://www.fontsquirrel.com/fonts/Titillium
****** 

------------------------------------------------------------------------------------------------------------------------------------------ 